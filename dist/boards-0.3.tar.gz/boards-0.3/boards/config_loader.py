import os

import yaml

from boards.arguments import args


def load_config(yml_path):
    with open(yml_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


if args.config:
    configFile = args.config
else:
    configFile = "config.yml"
config = load_config(configFile)
config["col_count"] = (args.col if args.col else config.get("col_count", []),)
config["margin"] = (args.margin if args.margin else config.get("margin", []),)

masterDir = config["masterDir"]
if args.config:
    masterDir = os.path.join(os.path.dirname(masterDir), os.basename(config))

suffix = ""

if args.upload:
    suffix = "_upload"
elif args.imageLists:
    suffix = "_imglist"

outputDir = masterDir + suffix
