from setuptools import find_packages, setup

setup(
    name="boards",
    version=0.2,
    packages=find_packages(),
    # install_requires = [
    # ]
)

# python3 setup.py sdist bdist_wheel